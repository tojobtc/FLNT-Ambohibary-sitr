<?php
$servername = "localhost";
$username   = "root"; // change si besoin
$password   = "";     // change si besoin
$dbname     = "flnt_chatbot";
$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {die("Connexion échouée: " . $conn->connect_error);}
$sql = "SELECT * FROM conversations ORDER BY date_message DESC";
$result = $conn->query($sql);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Admin - Conversations FLNT</title>
  <style>
    body { font-family: Arial, sans-serif; background:#f7f7f7; padding:20px; }
    h1 { color:#b71234; }
    table { border-collapse: collapse; width:100%; background:#fff; }
    th, td { border:1px solid #ddd; padding:8px; }
    th { background:#b71234; color:#fff; }
    tr:nth-child(even){ background:#f2f2f2; }
  </style>
</head>
<body>
  <h1>📋 Historique des conversations - FLNT</h1>
  <table>
    <tr><th>ID</th><th>Message utilisateur</th><th>Réponse bot</th><th>Date</th></tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <td><?= $row['id'] ?></td>
      <td><?= htmlspecialchars($row['message_user']) ?></td>
      <td><?= htmlspecialchars($row['message_bot']) ?></td>
      <td><?= $row['date_message'] ?></td>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
