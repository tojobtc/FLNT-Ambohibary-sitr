<?php
$servername = "localhost";
$username   = "root"; // à modifier si besoin
$password   = "";     // à modifier si besoin
$dbname     = "flnt_chatbot";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] === "POST" && isset($_POST["message"])) {
    $userMessage = strtolower(trim($_POST["message"]));
    $sql = "SELECT reponse FROM faq WHERE question LIKE ?";
    $stmt = $conn->prepare($sql);
    $search = "%" . $userMessage . "%";
    $stmt->bind_param("s", $search);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($row = $result->fetch_assoc()) {
        $botResponse = $row['reponse'];
    } else {
        $botResponse = "Désolé, je n'ai pas compris. Pouvez-vous reformuler ?";
    }
    $sqlInsert = "INSERT INTO conversations (message_user, message_bot) VALUES (?, ?)";
    $stmtInsert = $conn->prepare($sqlInsert);
    $stmtInsert->bind_param("ss", $userMessage, $botResponse);
    $stmtInsert->execute();
    echo $botResponse;
    exit;
}
?>
