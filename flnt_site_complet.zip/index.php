<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>FLNT - Vondrombavaka Lanitra No Tanjona</title>
  <meta name="description" content="Fiangonana Vondrombavaka Lanitra No Tanjona">
  <link rel="icon" href="favicon.ico">
  <style>
    body {font-family: Arial, sans-serif; margin:0; padding:0;}
    header {background:#b71234; color:white; padding:20px; text-align:center;}
    nav ul {list-style:none; padding:0; margin:0; display:flex; justify-content:center; gap:15px;}
    nav a {color:white; text-decoration:none; font-weight:bold;}
    footer {background:#111; color:#eee; text-align:center; padding:20px; margin-top:20px;}
    main {padding:20px;}
    /* --- Chatbot styles --- */
    #chatbot-toggle {
      position: fixed; bottom: 20px; right: 20px; width: 55px; height: 55px;
      background: #b71234; color: white; font-size: 24px;
      display: flex; align-items: center; justify-content: center;
      border-radius: 50%; box-shadow: 0 4px 6px rgba(0,0,0,0.3);
      cursor: pointer; z-index: 1001;
    }
    #chatbot-toggle:hover {background: #8a1028;}
    #chatbot-box {
      position: fixed; bottom: 80px; right: 20px; width: 320px; height: 400px;
      border: 1px solid #ccc; border-radius: 8px; background: white;
      display: none; flex-direction: column; box-shadow: 0 4px 8px rgba(0,0,0,0.2);
      z-index: 1000; font-family: Arial, sans-serif;
    }
    #chatbot-header {background: #b71234; color: white; padding: 8px 10px;
      border-radius: 8px 8px 0 0; font-weight: bold; display: flex; align-items: center;}
    #chatbot-header img {height: 25px; margin-right: 8px;}
    #chatbox {flex: 1; overflow-y: auto; padding: 10px; font-size: 14px;}
    .user {color: blue; margin: 5px 0;}
    .bot {color: green; margin: 5px 0;}
    #chatbot-input {display: flex; border-top: 1px solid #ddd; padding: 5px;}
    #userInput {flex: 1; border: 1px solid #ddd; border-radius: 5px; padding: 5px; margin-right: 5px;}
    #chatbot-input button {padding: 5px 10px; background: #b71234; border: none;
      border-radius: 5px; color: white; cursor: pointer;}
    #chatbot-input button:hover {background: #8a1028;}
    @media screen and (max-width: 600px) {
      #chatbot-box {width: 100%; right: 0; bottom: 0; height: 50vh; border-radius: 0;}
      #chatbot-toggle {bottom: 10px; right: 10px;}
    }
  </style>
</head>
<body>
  <header>
    <h1>Vondrombavaka Lanitra No Tanjona</h1>
    <nav>
      <ul>
        <li><a href="#mombamomba">Mombamomba</a></li>
        <li><a href="#tranga">Tranga</a></li>
        <li><a href="#fifandraisana">Fifandraisana</a></li>
      </ul>
    </nav>
  </header>
  <main>
    <section id="mombamomba">
      <h2>Mombamomba</h2>
      <p>Fampahalalana momba ny vondrombavaka FLNT.</p>
    </section>
    <section id="tranga">
      <h2>Tranga</h2>
      <p>Vaovao sy hetsika.</p>
    </section>
    <section id="fifandraisana">
      <h2>Fifandraisana</h2>
      <p>Email: contact@flnt.org</p>
    </section>
  </main>
  <footer>
    &copy; <?php echo date('Y'); ?> FLNT - Tous droits réservés.
  </footer>

  <!-- ✅ Chatbot -->
  <div id="chatbot-toggle" onclick="toggleChat()">💬</div>
  <div id="chatbot-box">
    <div id="chatbot-header">
      <img src="FLNT-LOGO.png" alt="FLNT">
      <span>Assistant FLNT</span>
      <span onclick="toggleChat()" style="margin-left:auto; cursor:pointer;">✖</span>
    </div>
    <div id="chatbox"></div>
    <div id="chatbot-input">
      <input type="text" id="userInput" placeholder="Posez votre question...">
      <button onclick="sendMessage()">➤</button>
    </div>
  </div>

  <script>
    function toggleChat() {
      let box = document.getElementById("chatbot-box");
      let toggle = document.getElementById("chatbot-toggle");
      if (box.style.display === "none" || box.style.display === "") {
        box.style.display = "flex";
        toggle.style.display = "none";
      } else {
        box.style.display = "none";
        toggle.style.display = "flex";
      }
    }
    function sendMessage() {
      let input = document.getElementById("userInput").value;
      if (input.trim() === "") return;
      let chatbox = document.getElementById("chatbox");
      chatbox.innerHTML += `<div class="user">Moi: ${input}</div>`;
      fetch("chatbot.php", {
        method: "POST",
        headers: { "Content-Type": "application/x-www-form-urlencoded" },
        body: "message=" + encodeURIComponent(input)
      })
      .then(response => response.text())
      .then(data => {
        chatbox.innerHTML += `<div class="bot">Bot: ${data}</div>`;
        chatbox.scrollTop = chatbox.scrollHeight;
      });
      document.getElementById("userInput").value = "";
    }
  </script>
</body>
</html>
