<?php
$servername = "localhost";
$username   = "root"; // à modifier si besoin
$password   = "";     // à modifier si besoin
$dbname     = "flnt_chatbot";

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connexion échouée: " . $conn->connect_error);
}

// Ajouter
if (isset($_POST['add'])) {
    $q = $_POST['question'];
    $r = $_POST['reponse'];
    $stmt = $conn->prepare("INSERT INTO faq (question, reponse) VALUES (?, ?)");
    $stmt->bind_param("ss", $q, $r);
    $stmt->execute();
}

// Modifier
if (isset($_POST['edit'])) {
    $id = $_POST['id'];
    $q = $_POST['question'];
    $r = $_POST['reponse'];
    $stmt = $conn->prepare("UPDATE faq SET question=?, reponse=? WHERE id=?");
    $stmt->bind_param("ssi", $q, $r, $id);
    $stmt->execute();
}

// Supprimer
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    $stmt = $conn->prepare("DELETE FROM faq WHERE id=?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
}

// Récupérer toutes les Q/R
$result = $conn->query("SELECT * FROM faq ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="fr">
<head>
  <meta charset="UTF-8">
  <title>Gestion FAQ - FLNT</title>
  <style>
    body { font-family: Arial, sans-serif; margin:20px; background:#f7f7f7; }
    h1 { color:#b71234; }
    form { margin-bottom:20px; background:#fff; padding:15px; border-radius:8px; box-shadow:0 2px 4px rgba(0,0,0,0.1);}
    input, textarea { width:100%; padding:8px; margin:5px 0; border:1px solid #ccc; border-radius:4px;}
    button { background:#b71234; color:white; border:none; padding:8px 12px; cursor:pointer; border-radius:4px;}
    button:hover { background:#8a1028; }
    table { width:100%; border-collapse: collapse; background:#fff; box-shadow:0 2px 4px rgba(0,0,0,0.1);}
    th, td { padding:10px; border:1px solid #ddd; }
    th { background:#b71234; color:white; }
    a { color:red; text-decoration:none; }
  </style>
</head>
<body>
  <h1>⚙️ Gestion des Questions/Réponses du Chatbot FLNT</h1>

  <!-- Formulaire ajout -->
  <form method="post">
    <h2>➕ Ajouter une Q/R</h2>
    <input type="text" name="question" placeholder="Question" required>
    <textarea name="reponse" placeholder="Réponse" required></textarea>
    <button type="submit" name="add">Ajouter</button>
  </form>

  <!-- Liste existante -->
  <h2>📋 Questions / Réponses existantes</h2>
  <table>
    <tr><th>ID</th><th>Question</th><th>Réponse</th><th>Actions</th></tr>
    <?php while($row = $result->fetch_assoc()): ?>
    <tr>
      <form method="post">
        <td><?= $row['id'] ?><input type="hidden" name="id" value="<?= $row['id'] ?>"></td>
        <td><input type="text" name="question" value="<?= htmlspecialchars($row['question']) ?>"></td>
        <td><textarea name="reponse"><?= htmlspecialchars($row['reponse']) ?></textarea></td>
        <td>
          <button type="submit" name="edit">✏️ Modifier</button>
          <a href="?delete=<?= $row['id'] ?>" onclick="return confirm('Supprimer cette Q/R ?')">❌ Supprimer</a>
        </td>
      </form>
    </tr>
    <?php endwhile; ?>
  </table>
</body>
</html>
